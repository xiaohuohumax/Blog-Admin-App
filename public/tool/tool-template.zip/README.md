# tool-template

## tool 模板已生成,你可以开始创作了!

## 注意点

+ vue-router 不支持 history 模式
+ 项目打包时后请压缩成 ZIP 格式 参考:[压缩包]("./dist.zip")
