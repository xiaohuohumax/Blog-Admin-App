import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

Vue.config.productionTip = false

// boostrap 样式 栅格24栏
import "./assets/bootstrap-24-4.4.1-dist/css/bootstrap.css";

// 沟通组件
import "./script/messageToParent"

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')