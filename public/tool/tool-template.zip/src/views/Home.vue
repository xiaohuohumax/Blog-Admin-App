<template>
  <div class="home d-flex justify-content-center align-items-center">
    <div>
      <div class="display-4">tool 模板已生成,你可以开始创作了!</div>
      <div class="mt-3">
        <div class="font-weight-bold">注意点:</div>
        <ul>
          <li>vue-router 不支持 history 模式</li>
          <li>项目打包时后请压缩成 ZIP 格式</li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>
<style lang="less">
.home {
  height: 100vh;
  background: paleturquoise;
  ul {
    list-style: none;
  }
}
</style>
